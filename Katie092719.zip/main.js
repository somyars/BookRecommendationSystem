$(document).ready(function () {
    console.log("I am called");

    fetchPopularBooks();
    fetchNewReleaseBooks();
    fetchAdultBooks();
    fetchChildrenBooks();
    fetchComicBooks();
    fetchHistoryBooks();
    fetchRomanceBooks();
    fetchPoetryBooks();
    fetchMysteryBooks();


    $(".image").css("transition", "transform 500ms ease-in-out");
    $(".image").hover(
        // Handler for mouseenter
        function () {
            $(this).css("transform", "scale(1.2)");
        },
        // Handler for mouseleave
        function () {
            $(this).css("transform", "scale(1)");
        }
    );
});

function openNav() {
    document.getElementById("mySidenav").style.display = "block";
    document.getElementById("box1").style.top = "400px";
    document.getElementById("box1").style.border = "1px solid #fff";
    document.getElementById("box1").style.transform = "scale(1)";
    document.getElementById("row").style.height = "800px";

    // document.getElementById("box1").style.display = "block";

}

function closeNav() {
    document.getElementById("mySidenav").style.display = "none";
    document.getElementById("box1").style.transform = "scale(1)";
    document.getElementById("box1").style.transition = "all 0.7s ease";
    document.getElementById("box1").style.border = "none";
}

function fetchPopularBooks() {
    console.log("In fetch popular books");
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:8000/api/books/?limit=5&order_by=-ratings_count&average_rating=5",
        data: JSON.stringify(),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var items = [];
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><img id='box1' src='" + value.image_url + "' width='180' height='250' style='padding:20px;'/></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");
            console.log(data);
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><p width='180' height='250' style='padding:20px;display:inline;color:white;'>" + value.title + "<br/>Average Rating:" + value.average_rating + "</p></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");

            $("#popularBooks").empty();
            $("#popularBooks").append(items);
            console.log("SUCCESS : ", data);
        },
        error: function (e) {
            console.log("ERROR : ", e);
        }
    });
}

function fetchNewReleaseBooks() {
    console.log("In new release books");
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: " http://localhost:8000/api/books/?limit=5&publication_year=2019.0",
        data: JSON.stringify(),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var items = [];
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><img id='box1' src='" + value.image_url + "' width='180' height='250' style='padding:20px;'/></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");
            console.log(data);
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><p width='180' height='250' style='padding:20px;display:inline;color:white;'>" + value.title + "<br/>Average Rating:" + value.average_rating + "</p></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");

            $("#newReleaseBooks").empty();
            $("#newReleaseBooks").append(items);
            console.log("SUCCESS : ", data);
        },
        error: function (e) {
            console.log("ERROR : ", e);
        }
    });
}

function fetchAdultBooks() {
    console.log("In adult books");
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: " http://localhost:8000/api/books/?genres__genre=Adult&limit=5&order_by=-average_rating",
        data: JSON.stringify(),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var items = [];
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><img id='box1' src='" + value.image_url + "' width='180' height='250' style='padding:20px;'/></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");
            console.log(data);
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><p width='180' height='250' style='padding:20px;display:inline;color:white;'>" + value.title + "<br/>Average Rating:" + value.average_rating + "</p></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");

            $("#adultBooks").empty();
            $("#adultBooks").append(items);
            console.log("SUCCESS : ", data);
        },
        error: function (e) {
            console.log("ERROR : ", e);
        }
    });
}

function fetchChildrenBooks() {
    console.log("In fetch children books");
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:8000/api/books/?genres__genre=Children&limit=5&order_by=-average_rating",
        data: JSON.stringify(),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var items = [];
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><img id='box1' src='" + value.image_url + "' width='180' height='250' style='padding:20px;'/></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");
            console.log(data);
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><p width='180' height='250' style='padding:20px;display:inline;color:white;'>" + value.title + "<br/>Average Rating:" + value.average_rating + "</p></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");

            $("#childrenBooks").empty();
            $("#childrenBooks").append(items);
            console.log("SUCCESS : ", data);
        },
        error: function (e) {
            console.log("ERROR : ", e);
        }
    });
}

function fetchComicBooks() {
    console.log("In fetch comic books");
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:8000/api/books/?genres__genre=Comics&limit=5&order_by=-average_rating",
        data: JSON.stringify(),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var items = [];
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><img id='box1' src='" + value.image_url + "' width='180' height='250' style='padding:20px;'/></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");
            console.log(data);
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><p width='180' height='250' style='padding:20px;display:inline;color:white;'>" + value.title + "<br/>Average Rating:" + value.average_rating + "</p></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");

            $("#comicBooks").empty();
            $("#comicBooks").append(items);
            console.log("SUCCESS : ", data);
        },
        error: function (e) {
            console.log("ERROR : ", e);
        }
    });
}

function fetchHistoryBooks() {
    console.log("In fetch history books");
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:8000/api/books/?genres__genre=History&limit=5&order_by=-average_rating",
        data: JSON.stringify(),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var items = [];
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><img id='box1' src='" + value.image_url + "' width='180' height='250' style='padding:20px;'/></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");
            console.log(data);
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><p width='180' height='250' style='padding:20px;display:inline;color:white;'>" + value.title + "<br/>Average Rating:" + value.average_rating + "</p></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");

            $("#historyBooks").empty();
            $("#historyBooks").append(items);
            console.log("SUCCESS : ", data);
        },
        error: function (e) {
            console.log("ERROR : ", e);
        }
    });
}

function fetchRomanceBooks() {
    console.log("In fetch romance books");
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:8000/api/books/?genres__genre=Romance&limit=5&order_by=-average_rating",
        data: JSON.stringify(),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var items = [];
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><img id='box1' src='" + value.image_url + "' width='180' height='250' style='padding:20px;'/></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");
            console.log(data);
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><p width='180' height='250' style='padding:20px;display:inline;color:white;'>" + value.title + "<br/>Average Rating:" + value.average_rating + "</p></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");

            $("#romanceBooks").empty();
            $("#romanceBooks").append(items);
            console.log("SUCCESS : ", data);
        },
        error: function (e) {
            console.log("ERROR : ", e);
        }
    });
}

function fetchPoetryBooks() {
    console.log("In fetch poetry books");
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:8000/api/books/?genres__genre=Poetry&limit=5&order_by=-average_rating",
        data: JSON.stringify(),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var items = [];
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><img id='box1' src='" + value.image_url + "' width='180' height='250' style='padding:20px;'/></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");
            console.log(data);
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><p width='180' height='250' style='padding:20px;display:inline;color:white;'>" + value.title + "<br/>Average Rating:" + value.average_rating + "</p></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");

            $("#poetryBooks").empty();
            $("#poetryBooks").append(items);
            console.log("SUCCESS : ", data);
        },
        error: function (e) {
            console.log("ERROR : ", e);
        }
    });
}

function fetchMysteryBooks() {
    console.log("In fetch mystery books");
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:8000/api/books/?genres__genre=Mystery&limit=5&order_by=-average_rating",
        data: JSON.stringify(),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var items = [];
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><img id='box1' src='" + value.image_url + "' width='180' height='250' style='padding:20px;'/></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");
            console.log(data);
            items.push("<tr>");
            $.each(data.objects, function (key, value) {
                items.push("<td><p width='180' height='250' style='padding:20px;display:inline;color:white;'>" + value.title + "<br/>Average Rating:" + value.average_rating + "</p></td>");
                console.log(value.book_id);
            });
            items.push("</tr>");

            $("#mysteryBooks").empty();
            $("#mysteryBooks").append(items);
            console.log("SUCCESS : ", data);
        },
        error: function (e) {
            console.log("ERROR : ", e);
        }
    });
}


//katie added
// referenced https://www.w3schools.com/howto/howto_js_toggle_hide_show.asp in this code
function viewAllPopularBooks() {
    var x = document.getElementById("sectionNewReleases");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionYouMayAlsoLike");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionChildren");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionComics");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionHistory");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionMystery");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionPoetry");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionAdult");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionRomance");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

}

function viewAllNewReleases() {
    var x = document.getElementById("sectionPopularBooks");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionYouMayAlsoLike");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionChildren");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionComics");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionHistory");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionMystery");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionPoetry");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionAdult");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionRomance");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

}

function viewAllChildren() {
    var x = document.getElementById("sectionPopularBooks");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionYouMayAlsoLike");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionNewReleases");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionComics");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionHistory");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionMystery");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionPoetry");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionAdult");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionRomance");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

}

function viewAllComics() {
    var x = document.getElementById("sectionPopularBooks");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionYouMayAlsoLike");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionNewReleases");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionChildren");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionHistory");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionMystery");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionPoetry");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionAdult");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionRomance");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

}

function viewAllHistory() {
    var x = document.getElementById("sectionPopularBooks");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionYouMayAlsoLike");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionNewReleases");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionChildren");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionComics");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionMystery");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionPoetry");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionAdult");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionRomance");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

}

function viewAllMystery() {
    var x = document.getElementById("sectionPopularBooks");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionYouMayAlsoLike");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionNewReleases");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionChildren");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionComics");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionHistory");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionPoetry");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionAdult");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionRomance");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

}

function viewAllPoetry() {
    var x = document.getElementById("sectionPopularBooks");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionYouMayAlsoLike");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionNewReleases");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionChildren");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionComics");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionHistory");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionMystery");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionAdult");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionRomance");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

}

function viewAllRomance() {
    var x = document.getElementById("sectionPopularBooks");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionYouMayAlsoLike");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionNewReleases");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionChildren");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionComics");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionHistory");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionMystery");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionAdult");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionPoetry");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

}

function viewAllAdult() {
    var x = document.getElementById("sectionPopularBooks");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionYouMayAlsoLike");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionNewReleases");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionChildren");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionComics");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionHistory");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionMystery");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionRomance");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    var x = document.getElementById("sectionPoetry");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

}